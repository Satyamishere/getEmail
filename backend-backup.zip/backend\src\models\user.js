import mongoose from 'mongoose'

const userschema=new mongoose.Schema({
    email:{
        type:String,
        required:true,
        unique:true
    },
    accessToken:{
        type:String
    },
    refreshToken:{
        type:String
    }
})
 const User=mongoose.model('User',userschema);
 export default User;